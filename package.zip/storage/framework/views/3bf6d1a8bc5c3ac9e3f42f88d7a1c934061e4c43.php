

<?php $__env->startSection('content'); ?>

<p class="pageTitle">
  <?php echo e($heading); ?>

</p>
<div class="GtableBox" >
  <table style="width:100%">
    <tr>
      <th>Game Name</th>
      <th>Number of Downloads</th>
      <th>Rating</th>
      <th>Platforms</th>
    </tr>
    <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($game['name']); ?></td>
      <td><?php echo e($game['added']); ?></td>
      <?php
      if($game['rating'] >= 4.5) {$rating_color = '#57e32c';}
      elseif ($game['rating'] >= 4) {$rating_color = '#b7dd29';}
      elseif ($game['rating'] >= 3.5) {$rating_color = '#ffe234';}
      elseif ($game['rating'] >= 3) {$rating_color = '#ffa534';}
      else {$rating_color = '#ff4545';}
      ?>
      <td style="color: <?php echo e($rating_color); ?>"><?php echo e($game['rating']); ?></td>
      <td>
      <?php $__currentLoopData = json_decode($game['parent_platforms'], true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <img class="game_card_info_platforms_icons" src="<?php echo e(asset('/images/icons/'.$platform['platform']['slug'].'.svg')); ?>"
      alt="<?php echo e($platform['platform']['name']); ?>">
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\htdocs\GroupProject403\resources\views/charts.blade.php ENDPATH**/ ?>
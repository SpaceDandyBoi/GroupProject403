
<?php
  $vids=[];
  $pics=[];
  $jsonPics="";
  foreach($games as $key=>$game){
    $vids[$key] = $gameExtra[$key][1];
    $pics[$key] = $game['background_image'];
    $jsonPics = $jsonPics.",".$game['background_image'];
  }
?>
<style type="text/css">
    .Game_Container {
        margin-left: 5%;
        margin-top: 3%;
        margin-right: 4%;
        display: flex;
        flex-direction: column;
    }

    #leftSide {
        width: 100%;
        height: 50%;
        display: flex;
        flex-wrap: wrap;
        overflow: hidden;
    }

    #Game_Name {
        font-family: 'Franklin Gothic Medium';
        font-size: 300%;
        color: white;
        -webkit-text-stroke: 0.1rem #010100;
    }

    #ratingBox {
        display: inline;
        border-radius: 0.25em;
        font-size: 200%;
        color: #010100;
        opacity: .7;
    }

    #imageGame {
        max-width: 100%;
        max-height: 100%;
        border-radius: 0.5em;
        margin: 5%;
    }

    .game_galary_top_middle {
        display: none;
    }

    #game_galary_bottom_pics_0 {
        border-style: solid;
    }

    #game_galary_top_middle_vid {
        display: block;
        border-style: none;
    }
    .game_title_info_container{
    height: fit-content;
    width: 100%;
    border-radius: 1em; /* don't change */
    background-color: rgba(0, 0, 0, 0.3);
    display: flex;
    flex-direction: row;
  }
  .game_title_info_container_left{

  }
  .game_title_info_container_right{
    padding-left: 5%;
    padding-top: 1%;
    
  } 
  .game_title_info_container_right_bottom{
    padding-right: 1%;
  }
  .game_summary{
    font-size: 150%;
  }
  .game_release{
    font-size: 150%;
  }

</style>

<?php $__env->startSection('content'); ?>


<p class="pageTitle">Home Page</p>
<p style="margin-left: 10%">This Is Our CPCS403 Project Please Enjoy:</p>
<div class="GtableBox">
<table style="width: 100%">
  <th>Developer Name</th>
  <th>Developer ID</th>
  <tr>
    <td><a href="/resume/Khalid_Alghamdi"> Khalid Alghamdi</a></td>
    <td>1936811</td>
  </tr>
  <tr>
    <td><a href="/resume/Mohammed_Alzahrani"> Mohammed Alzahrani</a></td>
    <td>1845613</td>
  </tr>
  <tr>
    <td><a href="/resume/Anas_Baubaid"> Anas Baubaid</a></td>
    <td>1936415</td>
  </tr>
  <tr>
    <td><a href="/resume/Abdullah_Fadaq"> Abdullah Fadaq</a></td>
    <td>1943267</td>
  </tr>
</table>
</div>

<p class="pageTitle" style="margin-top: 5%">recommended Games</p>



<script type="application/javascript">
  var jsonPics = "<?php echo e($jsonPics); ?>";
  jsonPics = jsonPics.substring(1);
  Pics = jsonPics.split(",");
  picNum = 0;
  picArr = Pics.length - 1;
  prevPic = 0;

  function UpdateGalary(action) {
      if (action == "next") {
          if ((picNum + 1) > picArr) {
              picNum = 0;
          } else {
              picNum = picNum + 1;
          }
      } else if (action == "previous") {
          if ((picNum - 1) < 0) {
              picNum = picArr;
          } else {
              picNum = picNum - 1;
          }
      } else {
          picNum = parseInt(action);
      }
      document.getElementById("game_galary_top_middle_vid_" + prevPic).style = "display: none";
      document.getElementById("game_galary_top_middle_vid_" + picNum).style = "display: block";
      document.getElementById("game_galary_bottom_pics_" + prevPic).style = "border-style: none";
      document.getElementById("game_galary_bottom_pics_" + picNum).style = "border-style: solid";
      prevPic = picNum;

  };
</script>

<div class="game_galary">
  <div class="game_galary_top">
      <div class="game_galary_top_left">
          <img class="game_galary_top_arrows" src="<?php echo e(asset('/images/icons/rounded_left_arrow.svg')); ?>"
              onclick="UpdateGalary('previous')">
      </div>
      <div class="game_galary_top_middle" id="game_galary_top_middle">
        <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($key == 0): ?>
            <iframe class="game_galary_top_middle_pic" id="<?php echo e('game_galary_top_middle_vid_'.$key); ?>" width="100%"
                height="100%" src="<?php echo e($vids[$key]); ?>">
            </iframe>
          <?php else: ?>
            <iframe class="game_galary_top_middle_pic" id="<?php echo e('game_galary_top_middle_vid_'.$key); ?>" width="100%"
              height="100%" src="<?php echo e($vids[$key]); ?>" style="display: none">
            </iframe>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="game_galary_top_right">
          <img class="game_galary_top_arrows" src="<?php echo e(asset('/images/icons/rounded_right_arrow.svg')); ?>"
              onclick="UpdateGalary('next')">
      </div>
  </div>
  <div class="game_galary_bottom">
      <?php $__currentLoopData = $pics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <img class="game_galary_bottom_pics" id="<?php echo e('game_galary_bottom_pics_' . $key); ?>"
              src="<?php echo e($pic); ?>" onclick="UpdateGalary('<?php echo e($key); ?>')">
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>


<?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="Game_Container">

        <div id="leftSide" name="leftSide" class="GameChild">
            <div class="game_title_info_container">
              <div class="game_title_info_container_left">
                <div style="height: 325px; width: 500px;">
                  <img id="imageGame" name="imageGame" src="<?php echo e($game['background_image']); ?>">
                </div>
              </div>
              <div class="game_title_info_container_right">
                <div class="game_title_info_container_right_top">
                  <a class="underline_link" href="/game/<?php echo e($game['slug']); ?>"><span id="Game_Name" name="Game_Name"><?php echo e($game['name']); ?></span> </a>
                  <?php
                  if ($game['rating'] >= 4.5) {
                      $rating_color = '#57e32c';
                  } elseif ($game['rating'] >= 4) {
                      $rating_color = '#b7dd29';
                  } elseif ($game['rating'] >= 3.5) {
                      $rating_color = '#ffe234';
                  } elseif ($game['rating'] >= 3) {
                      $rating_color = '#ffa534';
                  } else {
                      $rating_color = '#ff4545';
                  }
                  ?>
                  <div id="ratingBox" name="ratingBox"
                  style="background-color: <?php echo e($rating_color); ?>; border: 2% solid <?php echo e($rating_color); ?>;">
                  <?php echo e($game['rating']); ?>

                  </div>
                </div>
                <div class="game_title_info_container_right_bottom">
                  <p class="game_summary"> <?php echo e($gameExtra[0][0]); ?> </p>
                  <p class="game_release" style="display: inline"> Released: <?php echo e($game['released']); ?> </p>
                  <?php $__currentLoopData = json_decode($game['parent_platforms'], true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <img class="game_card_info_platforms_icons" src="<?php echo e(asset('/images/icons/'.$platform['platform']['slug'].'.svg')); ?>"
                  alt="<?php echo e($platform['platform']['name']); ?>">
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
            </div>
        </div>
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\htdocs\GroupProject403\resources\views/Home.blade.php ENDPATH**/ ?>
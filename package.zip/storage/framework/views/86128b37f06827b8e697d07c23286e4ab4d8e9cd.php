


<?php $__env->startSection('content'); ?>

<div>
    <p class="pageTitle">Resume of <?php echo e(str_replace('_',' ', $devName)); ?></p>
</div>

<div style="display: flex; justify-content: center; align-items: center; text-align: center; min-height: 100vh" >
    <object data='<?php echo e(asset("images/CVs/$devName.pdf")); ?>' type="application/pdf" width="1000" height="1000"></object>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\htdocs\GroupProject403\resources\views/resume.blade.php ENDPATH**/ ?>